n=int(input("Ingresar el valor final:"))
x=1
while   x<=n:
    print(x)
    x=x+1